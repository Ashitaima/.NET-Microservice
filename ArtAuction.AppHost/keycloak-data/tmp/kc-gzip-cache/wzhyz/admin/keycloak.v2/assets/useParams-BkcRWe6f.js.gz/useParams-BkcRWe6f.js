import{c as s}from"./main-PlBYn2XU.js";const r=()=>s();export{r as u};
//# sourceMappingURL=useParams-BkcRWe6f.js.map
