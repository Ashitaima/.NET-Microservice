import{cg as o}from"./main-PlBYn2XU.js";const e=t=>r=>r&&o(t,r)||"—";export{e as t};
//# sourceMappingURL=translationFormatter-Cxk4Y29c.js.map
